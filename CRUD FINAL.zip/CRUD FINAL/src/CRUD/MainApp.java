package CRUD;

public class MainApp extends javax.swing.JFrame {

    public MainApp() {

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        saveAsMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        cutMenuItem = new javax.swing.JMenuItem();
        copyMenuItem = new javax.swing.JMenuItem();
        pasteMenuItem = new javax.swing.JMenuItem();
        deleteMenuItem = new javax.swing.JMenuItem();
        menuInsertar = new javax.swing.JMenu();
        menucost = new javax.swing.JMenuItem();
        menuproducts = new javax.swing.JMenuItem();
        menuorders = new javax.swing.JMenuItem();
        menuorderitems = new javax.swing.JMenuItem();
        menuorderstatus = new javax.swing.JMenuItem();
        menuorderitemstatus = new javax.swing.JMenuItem();
        menushipment = new javax.swing.JMenuItem();
        menushipmentitem = new javax.swing.JMenuItem();
        menuinvoices = new javax.swing.JMenuItem();
        menuBrowse = new javax.swing.JMenu();
        menucost1 = new javax.swing.JMenuItem();
        menuproducts1 = new javax.swing.JMenuItem();
        menuorders1 = new javax.swing.JMenuItem();
        menuorderitems1 = new javax.swing.JMenuItem();
        menuorderstatus1 = new javax.swing.JMenuItem();
        menuorderitemstatus1 = new javax.swing.JMenuItem();
        menushipment1 = new javax.swing.JMenuItem();
        menushipmentitem1 = new javax.swing.JMenuItem();
        menuinvoices1 = new javax.swing.JMenuItem();
        menuDelete = new javax.swing.JMenu();
        menucost2 = new javax.swing.JMenuItem();
        menuproducts2 = new javax.swing.JMenuItem();
        menuorders2 = new javax.swing.JMenuItem();
        menuorderitems2 = new javax.swing.JMenuItem();
        menuorderstatus2 = new javax.swing.JMenuItem();
        menuorderitemstatus2 = new javax.swing.JMenuItem();
        menushipment2 = new javax.swing.JMenuItem();
        menushipmentitem2 = new javax.swing.JMenuItem();
        menuinvoices2 = new javax.swing.JMenuItem();

        jMenu2.setText("File");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Edit");
        jMenuBar1.add(jMenu3);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu");
        setMaximumSize(new java.awt.Dimension(550, 300));
        setMinimumSize(new java.awt.Dimension(550, 300));

        desktopPane.setBackground(java.awt.Color.black);
        desktopPane.setLayout(null);

        menuBar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        fileMenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        fileMenu.setMnemonic('f');
        fileMenu.setText("File");
        fileMenu.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N

        openMenuItem.setMnemonic('o');
        openMenuItem.setText("Open");
        fileMenu.add(openMenuItem);

        saveMenuItem.setMnemonic('s');
        saveMenuItem.setText("Save");
        fileMenu.add(saveMenuItem);

        saveAsMenuItem.setMnemonic('a');
        saveAsMenuItem.setText("Save As ...");
        saveAsMenuItem.setDisplayedMnemonicIndex(5);
        fileMenu.add(saveAsMenuItem);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        editMenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editMenu.setMnemonic('e');
        editMenu.setText("Editar");
        editMenu.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N

        cutMenuItem.setMnemonic('t');
        cutMenuItem.setText("Cut");
        cutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(cutMenuItem);

        copyMenuItem.setMnemonic('y');
        copyMenuItem.setText("Copy");
        copyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(copyMenuItem);

        pasteMenuItem.setMnemonic('p');
        pasteMenuItem.setText("Paste");
        editMenu.add(pasteMenuItem);

        deleteMenuItem.setMnemonic('d');
        deleteMenuItem.setText("Delete");
        editMenu.add(deleteMenuItem);

        menuBar.add(editMenu);

        menuInsertar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        menuInsertar.setText("Insertar");
        menuInsertar.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N

        menucost.setText("Costumers");
        menucost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menucostActionPerformed(evt);
            }
        });
        menuInsertar.add(menucost);

        menuproducts.setText("Products");
        menuInsertar.add(menuproducts);

        menuorders.setText("Orders");
        menuorders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuordersActionPerformed(evt);
            }
        });
        menuInsertar.add(menuorders);

        menuorderitems.setText("Order Items");
        menuorderitems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderitemsActionPerformed(evt);
            }
        });
        menuInsertar.add(menuorderitems);

        menuorderstatus.setText("Order Status Codes");
        menuorderstatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderstatusActionPerformed(evt);
            }
        });
        menuInsertar.add(menuorderstatus);

        menuorderitemstatus.setText("Order Item Status");
        menuInsertar.add(menuorderitemstatus);

        menushipment.setText("Shipments");
        menushipment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipmentActionPerformed(evt);
            }
        });
        menuInsertar.add(menushipment);

        menushipmentitem.setText("Shipment Item");
        menushipmentitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipmentitemActionPerformed(evt);
            }
        });
        menuInsertar.add(menushipmentitem);

        menuinvoices.setText("Invoices");
        menuinvoices.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuinvoicesActionPerformed(evt);
            }
        });
        menuInsertar.add(menuinvoices);

        menuBar.add(menuInsertar);

        menuBrowse.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        menuBrowse.setText("Buscar");
        menuBrowse.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N
        menuBrowse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuBrowseActionPerformed(evt);
            }
        });

        menucost1.setText("Costumers");
        menucost1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menucost1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menucost1);

        menuproducts1.setText("Products");
        menuBrowse.add(menuproducts1);

        menuorders1.setText("Orders");
        menuorders1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorders1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menuorders1);

        menuorderitems1.setText("Order Items");
        menuorderitems1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderitems1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menuorderitems1);

        menuorderstatus1.setText("Order Status Codes");
        menuorderstatus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderstatus1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menuorderstatus1);

        menuorderitemstatus1.setText("Order Item Status");
        menuBrowse.add(menuorderitemstatus1);

        menushipment1.setText("Shipments");
        menushipment1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipment1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menushipment1);

        menushipmentitem1.setText("Shipment Item");
        menushipmentitem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipmentitem1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menushipmentitem1);

        menuinvoices1.setText("Invoices");
        menuinvoices1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuinvoices1ActionPerformed(evt);
            }
        });
        menuBrowse.add(menuinvoices1);

        menuBar.add(menuBrowse);

        menuDelete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        menuDelete.setText("Borrar");
        menuDelete.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N

        menucost2.setText("Costumers");
        menucost2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menucost2ActionPerformed(evt);
            }
        });
        menuDelete.add(menucost2);

        menuproducts2.setText("Products");
        menuDelete.add(menuproducts2);

        menuorders2.setText("Orders");
        menuorders2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorders2ActionPerformed(evt);
            }
        });
        menuDelete.add(menuorders2);

        menuorderitems2.setText("Order Items");
        menuorderitems2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderitems2ActionPerformed(evt);
            }
        });
        menuDelete.add(menuorderitems2);

        menuorderstatus2.setText("Order Status Codes");
        menuorderstatus2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuorderstatus2ActionPerformed(evt);
            }
        });
        menuDelete.add(menuorderstatus2);

        menuorderitemstatus2.setText("Order Item Status");
        menuDelete.add(menuorderitemstatus2);

        menushipment2.setText("Shipments");
        menushipment2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipment2ActionPerformed(evt);
            }
        });
        menuDelete.add(menushipment2);

        menushipmentitem2.setText("Shipment Item");
        menushipmentitem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menushipmentitem2ActionPerformed(evt);
            }
        });
        menuDelete.add(menushipmentitem2);

        menuinvoices2.setText("Invoices");
        menuinvoices2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuinvoices2ActionPerformed(evt);
            }
        });
        menuDelete.add(menuinvoices2);

        menuBar.add(menuDelete);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 644, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(desktopPane, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void menuordersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuordersActionPerformed

    }//GEN-LAST:event_menuordersActionPerformed

    private void menucostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menucostActionPerformed

        //Abrir ventana InsertarCostumers
        insertarcostumers pr = new insertarcostumers(this,true);
        pr.setVisible(true);
        
    }//GEN-LAST:event_menucostActionPerformed

    private void menuBrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuBrowseActionPerformed
        
    }//GEN-LAST:event_menuBrowseActionPerformed

    private void menushipmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipmentActionPerformed

    }//GEN-LAST:event_menushipmentActionPerformed

    private void menuorderstatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderstatusActionPerformed

    }//GEN-LAST:event_menuorderstatusActionPerformed

    private void menuinvoicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuinvoicesActionPerformed

    }//GEN-LAST:event_menuinvoicesActionPerformed

    private void menuorderitemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderitemsActionPerformed

    }//GEN-LAST:event_menuorderitemsActionPerformed

    private void cutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutMenuItemActionPerformed


    }//GEN-LAST:event_cutMenuItemActionPerformed

    private void copyMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyMenuItemActionPerformed

    }//GEN-LAST:event_copyMenuItemActionPerformed

    private void menushipmentitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipmentitemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menushipmentitemActionPerformed

    private void menucost1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menucost1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menucost1ActionPerformed

    private void menuorders1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorders1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorders1ActionPerformed

    private void menuorderitems1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderitems1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorderitems1ActionPerformed

    private void menuorderstatus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderstatus1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorderstatus1ActionPerformed

    private void menushipment1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipment1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menushipment1ActionPerformed

    private void menushipmentitem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipmentitem1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menushipmentitem1ActionPerformed

    private void menuinvoices1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuinvoices1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuinvoices1ActionPerformed

    private void menucost2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menucost2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menucost2ActionPerformed

    private void menuorders2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorders2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorders2ActionPerformed

    private void menuorderitems2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderitems2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorderitems2ActionPerformed

    private void menuorderstatus2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuorderstatus2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuorderstatus2ActionPerformed

    private void menushipment2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipment2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menushipment2ActionPerformed

    private void menushipmentitem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menushipmentitem2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menushipmentitem2ActionPerformed

    private void menuinvoices2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuinvoices2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuinvoices2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainApp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem copyMenuItem;
    private javax.swing.JMenuItem cutMenuItem;
    private javax.swing.JMenuItem deleteMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuBrowse;
    private javax.swing.JMenu menuDelete;
    private javax.swing.JMenu menuInsertar;
    private javax.swing.JMenuItem menucost;
    private javax.swing.JMenuItem menucost1;
    private javax.swing.JMenuItem menucost2;
    private javax.swing.JMenuItem menuinvoices;
    private javax.swing.JMenuItem menuinvoices1;
    private javax.swing.JMenuItem menuinvoices2;
    private javax.swing.JMenuItem menuorderitems;
    private javax.swing.JMenuItem menuorderitems1;
    private javax.swing.JMenuItem menuorderitems2;
    private javax.swing.JMenuItem menuorderitemstatus;
    private javax.swing.JMenuItem menuorderitemstatus1;
    private javax.swing.JMenuItem menuorderitemstatus2;
    private javax.swing.JMenuItem menuorders;
    private javax.swing.JMenuItem menuorders1;
    private javax.swing.JMenuItem menuorders2;
    private javax.swing.JMenuItem menuorderstatus;
    private javax.swing.JMenuItem menuorderstatus1;
    private javax.swing.JMenuItem menuorderstatus2;
    private javax.swing.JMenuItem menuproducts;
    private javax.swing.JMenuItem menuproducts1;
    private javax.swing.JMenuItem menuproducts2;
    private javax.swing.JMenuItem menushipment;
    private javax.swing.JMenuItem menushipment1;
    private javax.swing.JMenuItem menushipment2;
    private javax.swing.JMenuItem menushipmentitem;
    private javax.swing.JMenuItem menushipmentitem1;
    private javax.swing.JMenuItem menushipmentitem2;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JMenuItem pasteMenuItem;
    private javax.swing.JMenuItem saveAsMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    // End of variables declaration//GEN-END:variables

}
