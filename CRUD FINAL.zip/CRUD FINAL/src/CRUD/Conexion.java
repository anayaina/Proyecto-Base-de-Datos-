package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {

    public static Connection getConexion() {

        Connection con = null;
        
        String url = "jdbc:postgresql://localhost/CRUD";
        String user = "postgres";
        String password = "Weareone";

        try {
            Class.forName("org.postgresql.Driver");

        } catch (ClassNotFoundException ex) {

            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {

            con = DriverManager.getConnection(url, user, password);

        } catch (SQLException ex) {

            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);

        }
        return con;
    }

    public static void main(String[] args) {

    }

}
